<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <div class="page-header">
            <h4 class="page-title">Profile</h4>
            <ul class="breadcrumbs">
                <li class="nav-home">
                    <a href="#">
                        <i class="flaticon-home"></i>
                    </a>
                </li>
                <li class="separator">
                    <i class="flaticon-right-arrow"></i>
                </li>
                <li class="nav-item">
                    <a href="#">Data</a>
                </li>
                <li class="separator">
                    <i class="flaticon-right-arrow"></i>
                </li>
                <li class="nav-item">
                    <a href="#">Profile</a>
                </li>
            </ul>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('karyawan-profile-update',$data->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="">Nama</label>
                                <input type="text" class="form-control" name="nama" value="<?php echo e($data->nama); ?>" id="">
                            </div>
                            <div class="form-group">
                                <label for="">Email</label>
                                <input type="text" class="form-control" name="email" value="<?php echo e($data->email); ?>" id="">
                            </div>
                            <div class="form-group">
                                <label for="">Nomor Telepon</label>
                                <input type="text" class="form-control" name="no_telp" value="<?php echo e($data->no_telp); ?>" id="">
                            </div>
                            <div class="form-group">
                                <label for="">Alamat</label>
                                <textarea name="alamat" id="" class="form-control" cols="30" rows="3"><?php echo e($data->alamat); ?></textarea>
                            </div>
                            <div class="form-group">
                                <label for="">Tempat Lahir</label>
                                <input type="text" class="form-control" name="tempat_lahir" value="<?php echo e($data->tempat_lahir); ?>" id="">
                            </div>
                            <div class="form-group">
                                <label for="">Tangal Lahir</label>
                                <input type="date" class="form-control" name="tanggal_lahir" value="<?php echo e($data->tanggal_lahir); ?>" id="">
                            </div>
                            <div class="form-group">
                                <label for="">Password</label>
                                <input type="password" class="form-control" name="password" id="" placeholder="Kosongkan jika tidak diubah">
                            </div>
                            <div class="form-group">
                                <button class="btn btn-primary">Simpan</button>
                                <a href="<?php echo e(route('karyawan-dashboard')); ?>" class="btn btn-primary btn-border">Kembali</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Files\Projek Laravel\absensi\resources\views/karyawan/profile.blade.php ENDPATH**/ ?>