<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <div class="page-header">
            <h4 class="page-title">Rekap Kehadiran</h4>
            <ul class="breadcrumbs">
                <li class="nav-home">
                    <a href="#">
                        <i class="flaticon-home"></i>
                    </a>
                </li>
                <li class="separator">
                    <i class="flaticon-right-arrow"></i>
                </li>
                <li class="nav-item">
                    <a href="#">Data</a>
                </li>
                <li class="separator">
                    <i class="flaticon-right-arrow"></i>
                </li>
                <li class="nav-item">
                    <a href="#">Rekap Kehadiran</a>
                </li>
            </ul>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <form action="<?php echo e(route('rekap-kehadiran-filter')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-4">
                                <input type="text" class="form-control" id="daterangepicker" name="tanggal">
                            </div>
                            <div class="col-4">
                                <select name="tipe" id="" class="form-control">
                                    <option value="">Semua</option>
                                    <option value="masuk" <?php if($btn == 'filter' && $filter['tipe'] == 'masuk'): ?> selected <?php endif; ?>>Masuk</option>
                                    <option value="keluar" <?php if($btn == 'filter' && $filter['tipe'] == 'keluar'): ?> selected <?php endif; ?>>Keluar</option>
                                </select>
                            </div>
                            <div class="col-4">
                                <button type="submit" class="btn btn-primary btn-block">Cari</button>
                            </div>
                        </div>
                    </form>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="cek" class="display table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Waktu</th>
                                        <th>Lokasi</th>
                                        <th>Tipe</th>
                                        <th>Status</th>
                                        <th>Gambar</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $no=1;
                                    ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($no++); ?></td>
                                            <td><?php echo e(\Carbon\Carbon::parse($data->waktu)->translatedFormat('l, d F Y H:i:s')); ?></td>
                                            <td><?php echo e($data->lokasi); ?></td>
                                            <td><?php echo e($data->tipe); ?></td>
                                            <td><?php echo e($data->status); ?></td>
                                            <td><a href="<?php echo e(asset('presensi/'.$data->gambar)); ?>" target="_blank"><img src="<?php echo e(asset('presensi/'.$data->gambar)); ?>" style="max-width: 200px" alt=""></a></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<script>
    $('#daterangepicker').daterangepicker({
            locale: {
                'format': 'YYYY-MM-DD',
            },
            ranges: {
                'Hari Ini': [moment(), moment()],
                'Kemarin': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                '7 Hari Terakhir': [moment().subtract(6, 'days'), moment()],
                '30 Hari Terakhir': [moment().subtract(29, 'days'), moment()],
                'Bulan Ini': [moment().startOf('month'), moment().endOf('month')],
                'Bulan Kemarin': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month')
                    .endOf('month')
                ]
            }
        });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Files\Projek Laravel\absensi\resources\views/karyawan/kehadiran_rekap.blade.php ENDPATH**/ ?>