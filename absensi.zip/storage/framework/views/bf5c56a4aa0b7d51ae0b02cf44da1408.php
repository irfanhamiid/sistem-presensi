<ul class="nav nav-primary">
    <li class="nav-item">
        <a href="<?php echo e(route('admin-dashboard')); ?>">
            <i class="fas fa-home"></i>
            <p>Dashboard</p>
        </a>
    </li>
    <li class="nav-section">
        <span class="sidebar-mini-icon">
            <i class="fa fa-ellipsis-h"></i>
        </span>
        <h4 class="text-section">Data</h4>
    </li>
    <li class="nav-item">
        <a href="<?php echo e(route('karyawan-list')); ?>">
            <i class="fas fa-users"></i>
            <p>Karyawan</p>
        </a>
    </li>
    <li class="nav-item">
        <a href="<?php echo e(route('laporan-kehadiran')); ?>">
            <i class="fas fa-book"></i>
            <p>Laporan Absensi</p>
        </a>
    </li>
    <li class="nav-item">
        <a href="<?php echo e(route('jam-kerja')); ?>">
            <i class="fas fa-clock"></i>
            <p>Setting Jam Kerja</p>
        </a>
    </li>
</ul>
<?php /**PATH C:\Files\Projek Laravel\absensi\resources\views/inc/admin.blade.php ENDPATH**/ ?>