<ul class="nav nav-primary">
    <li class="nav-item">
        <a href="<?php echo e(route('karyawan-dashboard')); ?>">
            <i class="fas fa-home"></i>
            <p>Dashboard</p>
        </a>
    </li>
    <li class="nav-section">
        <span class="sidebar-mini-icon">
            <i class="fa fa-ellipsis-h"></i>
        </span>
        <h4 class="text-section">Data</h4>
    </li>
    <li class="nav-item">
        <a href="<?php echo e(route('rekap-kehadiran')); ?>">
            <i class="fas fa-book"></i>
            <p>Rekap Kehadiran</p>
        </a>
    </li>
</ul>
<?php /**PATH C:\Files\Projek Laravel\absensi\resources\views/inc/karyawan.blade.php ENDPATH**/ ?>