<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Rekap Presensi Bulan <?php echo e(\Carbon\Carbon::parse('Y F')->translatedFormat('F Y')); ?></title>
    <style>
        body {
            font-family: Helvetica, sans-serif;
            font-size: 11px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            border: 1px solid black;
            padding: 5px;
            text-align: center;
        }

        th {
            background-color: #f2f2f2;
        }

        /* Atur lebar kolom agar lebih rapi */
        th:nth-child(1),
        td:nth-child(1) {
            width: 5%;
        }

        th:nth-child(2),
        td:nth-child(2) {
            width: 20%;
        }

        th:nth-child(3),
        td:nth-child(3) {
            width: 15%;
        }

        th:nth-child(4),
        td:nth-child(4) {
            width: 30%;
        }

        th:nth-child(5),
        td:nth-child(5) {
            width: 35%;
        }

        h4 {
            text-align: center;
            margin-bottom: 20px;
        }
    </style>
</head>

<body>
    <h4>Rekap Presensi <?php echo e(\Carbon\Carbon::parse('F Y')->translatedFormat('F Y')); ?></h4>
    <br>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Waktu</th>
                <th>Jenis Presensi</th>
                <th>Lokasi</th>
                <th>Status</th>
            </tr>
        </thead>
        <?php
            $no = 1;
        ?>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($data->nama); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($data->waktu)->translatedFormat('l, d F Y H:i:s')); ?></td>
                    <td><?php echo e($data->tipe); ?></td>
                    <td><?php echo e($data->lokasi); ?></td>
                    <td><?php echo e($data->status); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH C:\Files\Projek Laravel\absensi\resources\views/admin/presensi_pdf.blade.php ENDPATH**/ ?>