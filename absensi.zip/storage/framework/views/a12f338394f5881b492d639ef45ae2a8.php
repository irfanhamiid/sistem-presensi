<?php $__env->startSection('content'); ?>
    <div class="page-inner">
        <div class="page-header">
            <h4 class="page-title">Karyawan</h4>
            <ul class="breadcrumbs">
                <li class="nav-home">
                    <a href="#">
                        <i class="flaticon-home"></i>
                    </a>
                </li>
                <li class="separator">
                    <i class="flaticon-right-arrow"></i>
                </li>
                <li class="nav-item">
                    <a href="#">Data</a>
                </li>
                <li class="separator">
                    <i class="flaticon-right-arrow"></i>
                </li>
                <li class="nav-item">
                    <a href="#">Karyawan</a>
                </li>
            </ul>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e($action); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="">Nama Karyawan</label>
                                <input type="text" class="form-control" name="nama" <?php if($btn == 'edit'): ?> value="<?php echo e($data->nama); ?>" <?php endif; ?> id="" required placeholder="Masukkan Nama Karyawan">
                            </div>
                            <div class="form-group">
                                <label for="">Email</label>
                                <input type="text" class="form-control" name="email" <?php if($btn == 'edit'): ?> value="<?php echo e($data->email); ?>" <?php endif; ?> id="" required placeholder="Masukkan Email Karyawan">
                            </div>
                            <div class="form-group">
                                <label for="">Nomor Telepon</label>
                                <input type="text" class="form-control" name="no_telp" <?php if($btn == 'edit'): ?> value="<?php echo e($data->no_telp); ?>" <?php endif; ?> id="" required placeholder="Masukkan Nomor Telepon">
                            </div>
                            <div class="form-group">
                                <label for="">Alamat</label>
                                <textarea name="alamat" class="form-control" id="" cols="30" rows="5" placeholder="Masukkan alamat"><?php if($btn == 'edit'): ?><?php echo e($data->alamat); ?><?php endif; ?></textarea>
                            </div>
                            <div class="form-group">
                                <label for="">Jenis Kelamin</label>
                                <select name="jenis_kelamin" class="form-control" id="">
                                    <option value="">Pilih Jenis Kelamin</option>
                                    <option value="Laki-laki" <?php if($btn == 'edit' && $data->jenis_kelamin == "Laki-laki"): ?> selected <?php endif; ?>>Laki-laki</option>
                                    <option value="Perempuan" <?php if($btn == 'edit' && $data->jenis_kelamin == "Perempuan"): ?> selected <?php endif; ?>>Perempuan</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="">Agama</label>
                                <select name="agama" class="form-control" id="">
                                    <option value="">Pilih Agama</option>
                                    <option value="Islam" <?php if($btn == 'edit' && $data->agama == "Islam"): ?> selected <?php endif; ?>>Islam</option>
                                    <option value="Kristen" <?php if($btn == 'edit' && $data->agama == "Kristen"): ?> selected <?php endif; ?>>Kristen</option>
                                    <option value="Katolik" <?php if($btn == 'edit' && $data->agama == "Katolik"): ?> selected <?php endif; ?>>Katolik</option>
                                    <option value="Hindu" <?php if($btn == 'edit' && $data->agama == "Hindu"): ?> selected <?php endif; ?>>Hindu</option>
                                    <option value="Buddha" <?php if($btn == 'edit' && $data->agama == "Buddha"): ?> selected <?php endif; ?>>Buddha</option>
                                    <option value="Konghucu" <?php if($btn == 'edit' && $data->agama == "Konghucu"): ?> selected <?php endif; ?>>Konghucu</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="">Tempat Lahir</label>
                                <input type="text" class="form-control" name="tempat_lahir" id="" <?php if($btn == 'edit'): ?> value="<?php echo e($data->tempat_lahir); ?>" <?php endif; ?> placeholder="Masukkan Tempat Lahir">
                            </div>
                            <div class="form-group">
                                <label for="">Tanggal Lahir</label>
                                <input type="date" class="form-control" name="tanggal_lahir" id="" <?php if($btn == 'edit'): ?> value="<?php echo e($data->tanggal_lahir); ?>" <?php endif; ?>>
                            </div>
                            <div class="form-group">
                                <label for="">Password</label>
                                <input type="password" class="form-control" name="password" <?php if($btn == 'add'): ?> required <?php endif; ?> id="" placeholder="Masukkan Password">
                            </div>
                            <div class="form-group">
                                <button class="btn btn-primary" type="submit">Simpan</button>
                                <a href="<?php echo e(route('karyawan-list')); ?>" class="btn btn-warning">Kembali</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Files\Projek Laravel\absensi\resources\views/admin/karyawan_form.blade.php ENDPATH**/ ?>